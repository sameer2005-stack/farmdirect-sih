# FarmDirect — merged frontend

This package keeps the uploaded FarmDirect homepage design and adds backend-connected pages for:

- Login / registration
- Buyer cart and order creation
- Buyer order history and tracking
- Farmer order acceptance/rejection
- Delivery creation and driver assignment
- Delivery-partner status updates

## Files

- `index.html` — your original homepage, with working links added
- `api.js` — shared API/JWT helpers
- `styles.css` — styles for the new pages
- `login.html`
- `register.html`
- `cart.html`
- `orders.html`
- `order.html`
- `farmer-orders.html`
- `delivery.html`

## Run

1. Put these files in the same frontend folder.
2. Start the existing FarmDirect backend on `http://localhost:5000`.
3. Open the frontend through a local web server rather than `file://` (for example VS Code Live Server).
4. Register accounts for Buyer, Farmer and Delivery Partner.
5. Farmers must create products through the existing backend/API before buyers can place real orders.

The current backend requires all items in one order to belong to the same farmer, so the cart enforces that rule.

The delivery tracker is intentionally a UI preview: the current backend stores pickup/destination as text and does not expose GPS latitude/longitude or a live map feed.
