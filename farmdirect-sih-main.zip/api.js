const API_BASE = "http://localhost:5000/api";

function getToken() {
  return localStorage.getItem("farmdirect_token");
}
function getUser() {
  try { return JSON.parse(localStorage.getItem("farmdirect_user") || "null"); }
  catch { return null; }
}
function saveSession(data) {
  localStorage.setItem("farmdirect_token", data.token);
  localStorage.setItem("farmdirect_user", JSON.stringify(data.user));
}
function clearSession() {
  localStorage.removeItem("farmdirect_token");
  localStorage.removeItem("farmdirect_user");
}
function requireAuth(roles = []) {
  const user = getUser();
  if (!getToken() || !user) {
    location.href = "login.html";
    return null;
  }
  if (roles.length && !roles.includes(user.role)) {
    alert("This page is not available for your account role.");
    location.href = "index.html";
    return null;
  }
  return user;
}
async function api(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(API_BASE + path, { ...options, headers });
  const text = await res.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { message: text }; }
  if (!res.ok) throw new Error(data.message || data.error || `Request failed (${res.status})`);
  return data;
}
function money(v) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(Number(v || 0));
}
function fmtDate(v) {
  if (!v) return "-";
  return new Date(v).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });
}
function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;" }[c]));
}
function cartItems() {
  try { return JSON.parse(localStorage.getItem("farmdirect_cart") || "[]"); }
  catch { return []; }
}
function saveCart(items) {
  localStorage.setItem("farmdirect_cart", JSON.stringify(items));
}
function logout() {
  clearSession();
  location.href = "index.html";
}
